# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Yahoo::Application.config.secret_token = 'aaf9ac26a46b195d512ea8b44f9a3d6c2497c6ee99754644f784ef983815b5ab5392addafab23197e650342ea3614b25b4f43cf91035d5655259a872d3326e83'
