require 'test_helper'

class DairiesHelperTest < ActionView::TestCase
end
