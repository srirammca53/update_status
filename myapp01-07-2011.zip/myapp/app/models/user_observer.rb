class UserObserver < ActiveRecord::Observer
observer :user
def after_validation(model)

 dairy.address = dairy.name.capitalize 
end
end
