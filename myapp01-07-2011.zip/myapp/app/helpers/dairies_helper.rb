module DairiesHelper
end
