# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Firstapplication::Application.config.secret_token = 'e8ecf0f2507c15d22953e0f0b9efa084ed63080c9b6085fc43ef0c7d4a32debe6bd0e4ff254dbb8eb45d8ab755312b541d67943515188f29bcf98d2ee230a243'
