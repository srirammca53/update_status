# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
OnetooneRelationApp::Application.config.secret_token = '07301cf2122543fd4752a8a3ad1fa4b99f8f58ec8f079517f57ab12f49dd236ce8c5b94e3e07c4e9f7f0f39a34e38000c5395da32a237092086ecad329934dc4'
