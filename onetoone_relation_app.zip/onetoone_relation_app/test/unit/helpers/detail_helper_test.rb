require 'test_helper'

class DetailHelperTest < ActionView::TestCase
end
