class Detail < ActiveRecord::Base
end
