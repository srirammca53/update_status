class DetailController < ApplicationController
end
