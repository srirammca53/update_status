# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Sriram::Application.config.secret_token = '60e57411784f0ad0756d0d574a43534e48ff6bc6d7881292af455cf691d38cc16ba926fb3f9b83987bf0d79b8398e470dc1d640d01f062b87a9c38b9f96cbe60'
