module DetailHelper
end
