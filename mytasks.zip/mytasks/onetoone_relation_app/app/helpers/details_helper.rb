module DetailsHelper
end
