require 'test_helper'

class DetailsHelperTest < ActionView::TestCase
end
