module VendorsHelper
end
