# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ManytomanyRelationApp::Application.config.secret_token = '720da3519b034fa7bb738042b5390c60c78bdb800c3bdf4579665e1d261980baad8e86ea43441d04ce4a8d71a8da9f2960a51cbca0504622b10a269885ef7871'
