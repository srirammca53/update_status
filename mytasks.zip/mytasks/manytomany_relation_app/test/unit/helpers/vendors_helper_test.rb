require 'test_helper'

class VendorsHelperTest < ActionView::TestCase
end
