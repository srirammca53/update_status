require 'test_helper'

class ClientsHelperTest < ActionView::TestCase
end
