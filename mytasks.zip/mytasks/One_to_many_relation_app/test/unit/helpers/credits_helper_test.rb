require 'test_helper'

class CreditsHelperTest < ActionView::TestCase
end
