class Credit < ActiveRecord::Base
  belongs_to :banks
end
