# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
One_to_many_relation_app::Application.config.secret_token = 'cad2cc432baea7cc5d9586dc29fbf673774c7a177b988b1aa11137cc2f5b2fd25a40d2e987f9ccd2ab880bf2875436e360d1aa988590050ea1825ed89eb1dffd'
