require 'test_helper'

class OfficesHelperTest < ActionView::TestCase
end
