# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Useroffice::Application.config.secret_token = '2ea194f53dc30fe5828f203013d42c87c553258cb4d286bcb9351bd231da945b86286e04c80eae42621d674fff0077a3142df6f9ea0d125e1bb3374db1dbc367'
