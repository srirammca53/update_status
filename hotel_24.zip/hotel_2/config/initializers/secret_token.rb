# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Hotel::Application.config.secret_token = 'abd542affd10777e21f26d485bf2d721b50861d6d83e91e293515061b44b66759b791e232742b36eced3a6ede6835f190f6a801c9c62be1dcd36912a02b0b5f8'
