class Booking < ActiveRecord::Base
  belongs_to :customer
end
