class BookingsController < ApplicationController
def create
    @customer = Customer.find(params[:customer_id])
    @booking = @customer.bookings.create(params[:booking])
    redirect_to customer_path(@customer)
  end
end
