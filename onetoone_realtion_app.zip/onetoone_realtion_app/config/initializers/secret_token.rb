# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
OnetooneRealtionApp::Application.config.secret_token = '817390726ca637f106c262476b434d99a09de8614fc6858481ed71d96205061f3f6fe3d074a9fa6c1bb1953b1b6cfc062b17131bcac27deedddd082a3b271e47'
