require 'test_helper'

class ReservationsHelperTest < ActionView::TestCase
end
