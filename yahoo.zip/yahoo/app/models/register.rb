class Register < ActiveRecord::Base
end
