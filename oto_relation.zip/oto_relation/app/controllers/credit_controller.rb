class CreditController < ApplicationController
def create
    @account = Account.find(params[:account_id])
    @credit = @account.credit.create(params[:credit])
    redirect_to account_path(@account)
  end
end
