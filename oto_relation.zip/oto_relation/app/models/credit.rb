class Credit < ActiveRecord::Base
  belongs_to :account
end
