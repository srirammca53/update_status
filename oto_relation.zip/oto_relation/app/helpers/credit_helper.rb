module CreditHelper
end
