require 'test_helper'

class CreditHelperTest < ActionView::TestCase
end
