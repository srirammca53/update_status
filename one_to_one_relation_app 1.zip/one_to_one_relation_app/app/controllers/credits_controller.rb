class CreditsController < ApplicationController
end
