module CreditsHelper
end
