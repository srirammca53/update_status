class Tag < ActiveRecord::Base
  belongs_to :post
end
