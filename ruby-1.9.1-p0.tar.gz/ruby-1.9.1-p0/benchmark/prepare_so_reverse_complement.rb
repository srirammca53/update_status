require File.join(File.dirname(__FILE__), 'make_fasta_output')
prepare_fasta_output(2_500_000)
