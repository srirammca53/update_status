require 'test_helper'

class StoresHelperTest < ActionView::TestCase
end
