class Admin < ActiveRecord::Base
end
