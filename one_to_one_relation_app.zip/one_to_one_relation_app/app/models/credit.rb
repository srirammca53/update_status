class Credit < ActiveRecord::Base
  belongs_to :bank
end
