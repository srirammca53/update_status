class Bank < ActiveRecord::Base
 has_many :credits
end
