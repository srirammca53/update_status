class CreditController < ApplicationController
def create
    @account = Account.find(params[:account_id])
    @credit = @account.credit.create(params[:credit])
    redirect_to account_path(@account)
  end
 def new
    @credit = Credit.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @credit }
    end
  end
end
