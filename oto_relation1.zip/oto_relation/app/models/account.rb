class Account < ActiveRecord::Base
has_one :credit
end
