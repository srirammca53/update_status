# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
OtoRelation::Application.config.secret_token = 'd5744c38537e85594fc7d83198b6bc2a22e1ac29b34bc1e2007576c3115ae03bb061de057136eadf98bb7eaf329e4a65746cb52e861b00a91272b856a0a09684'
