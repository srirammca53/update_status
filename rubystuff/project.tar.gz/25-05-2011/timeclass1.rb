

# program using Time class

t =Time.now
puts t.strftime("%d/%m/%Y %H:%M:%S")  
puts t.strftime("%A")  
puts t.strftime("%a")  
puts t._dump



