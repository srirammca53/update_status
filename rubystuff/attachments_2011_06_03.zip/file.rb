# program to read content from exixting file and count the no of words


afile = File.open("file.txt","r")
yes = File.exists?("file.txt")

if yes.to_s == "true"
counts = afile.readlines("file.txt")
word = (counts.to_s).split(" ")
puts "No Of words in the file #{word.length}"
else
puts " File not found"
end
