# program on abstract class
class Abstractclass
def details(id)
  
end
def id; "hello";end
def id; puts id ; end

end
c1 = Abstractclass.new()
c1.details(3)
