#--
# PDF::Writer for Ruby.
#   http://rubyforge.org/projects/ruby-pdf/
#   Copyright 2003 - 2005 Austin Ziegler.
#
#   Licensed under a MIT-style licence. See LICENCE in the main distribution
#   for full licensing information.
#
# $Id: charts.rb 50 2005-05-16 03:59:21Z austin $
#++
  # A namespace for charts that can be drawn on PDF::Writer canvases.
module PDF::Charts
end
