# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Myapp::Application.config.secret_token = '869e7bff6938b51cc452e0fb46c88083f821cf6539a1fd2a8390508a26a37f05857b20e78e0735c517a1090d14029a08b7a59d4e1add8d096378c9ad6503d1f9'
