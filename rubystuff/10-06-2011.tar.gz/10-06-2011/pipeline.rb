
# pipeline is nothing but chains of commands  the output of one become the input of the next

